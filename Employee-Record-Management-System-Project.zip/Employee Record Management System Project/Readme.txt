How to run this project

1. Download the the zip file
2. Extract the file and copy erms folder
3.Paste inside root directory(for xampp xampp/htdocs, for wamp wamp/www, for lamp var/www/html)
4. Open phpmyadmin (http://localhost/phpmyadmin)
5. Create a database with name ermsdb
6. Import ermsdb.sql file(given inside the zip package in sql file folder)
7.Run the script http://localhost/erms (frontend)

Credential for user panel :
username : testuser@gmail.com
Password : Test @123
Credential for admin panel :
username : admin
Password : Test @123


