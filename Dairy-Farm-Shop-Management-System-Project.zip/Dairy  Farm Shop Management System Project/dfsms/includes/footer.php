            <div class="hk-footer-wrap container">
                <footer class="footer">
                    <div class="row">
                        <div class="col-md-6 col-sm-12">
<p>Developed By<a href="https://phpgurukul.com/" class="text-dark">PHPGurukul</a> ©2019</p>
                        </div>
                    </div>
                </footer>
            </div>